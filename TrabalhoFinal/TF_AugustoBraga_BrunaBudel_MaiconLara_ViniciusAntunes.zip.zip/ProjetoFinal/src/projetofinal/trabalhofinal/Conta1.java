/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package trabalhofinal;

/**
 *
 * @author maico
 */
public interface Conta1 {
    
    public boolean deposita(double valor);
    public boolean saca(double valor);
    public String getDono();
    public int getNumero();
    public double getSaldo();
    public void remunera();
    
}
