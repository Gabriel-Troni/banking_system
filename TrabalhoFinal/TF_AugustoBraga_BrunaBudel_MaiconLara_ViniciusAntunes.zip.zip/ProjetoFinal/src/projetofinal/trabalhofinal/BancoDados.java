/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabalhofinal;

import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author rafae
 */
public class BancoDados {
    public static List<Cliente> listaClientes = new ArrayList<Cliente>();
    public static List<Conta> listaContas = new ArrayList<Conta>(); 
    
}